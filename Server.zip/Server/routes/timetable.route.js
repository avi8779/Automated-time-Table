import { Router } from "express";
import {
  generateTimetableController,
  getTimetableBySection
} from "../Controller/timetable.controller.js";

const router = Router();

router.post("/generate", generateTimetableController);
router.get("/section/:section_id", getTimetableBySection);

export default router;
