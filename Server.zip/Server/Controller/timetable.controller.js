import asyncHandler from "../middleware/asyncHandler.middleware.js";
import AppError from "../utils/appError.js";
import { generateTimetable } from "../Services/timetable.service.js";
import { pool } from "../config/dbConn.js";

/* generate timetable */
export const generateTimetableController = asyncHandler(async (_req, res) => {
  const result = await generateTimetable();

  res.status(201).json({
    success: true,
    message: result.message
  });
});

/* get timetable by section */
export const getTimetableBySection = asyncHandler(async (req, res) => {
  const { section_id } = req.params;

  const [rows] = await pool.query(
    `SELECT 
       tt.timetable_id,
       s.name AS subject_name,
       t.name AS teacher_name,
       r.room_code,
       ts.day,
       ts.start_time,
       ts.end_time
     FROM timetables tt
     JOIN subjects s ON s.subject_id = tt.subject_id
     JOIN teachers t ON t.teacher_id = tt.teacher_id
     JOIN rooms r ON r.room_id = tt.room_id
     JOIN time_slots ts ON ts.slot_id = tt.slot_id
     WHERE tt.section_id = ?
     ORDER BY ts.day, ts.start_time`,
    [section_id]
  );

  if (!rows.length) {
    throw new AppError("No timetable found for this section", 404);
  }

  res.json({
    success: true,
    count: rows.length,
    data: rows
  });
});
