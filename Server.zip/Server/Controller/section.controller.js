import {
  sectionNameExists,
  courseExistsById,
  createSection,
  getAllSections,
  getSectionById,
  updateSection,
  softDeleteSection
} from "../model/section.model.js";

/* ===================== CREATE SECTION ===================== */
export const createSectionController = async (req, res) => {
  try {
    const {
      section_name,
      course_id,
      semester,
      strength,
      batch_year,
      status
    } = req.body;

    // basic validation
    if (
      !section_name ||
      !course_id ||
      !semester ||
      !strength ||
      !batch_year ||
      !status
    ) {
      return res.status(400).json({ message: "All fields are required" });
    }

    // check section name
    if (await sectionNameExists(section_name)) {
      return res.status(409).json({ message: "Section already exists" });
    }

    // check course
    if (!(await courseExistsById(course_id))) {
      return res.status(404).json({ message: "Course not found" });
    }

    const section_id = await createSection({
      section_name,
      course_id,
      semester,
      strength,
      batch_year,
      status
    });

    res.status(201).json({
      message: "Section created successfully",
      section_id
    });
  } catch (error) {
    console.error("Create Section Error:", error);
    res.status(500).json({ message: "Internal server error" });
  }
};

/* ===================== GET ALL SECTIONS ===================== */
export const getAllSectionsController = async (req, res) => {
  try {
    const sections = await getAllSections();
    res.status(200).json(sections);
  } catch (error) {
    console.error("Get Sections Error:", error);
    res.status(500).json({ message: "Internal server error" });
  }
};

/* ===================== GET SECTION BY ID ===================== */
export const getSectionByIdController = async (req, res) => {
  try {
    const { id } = req.params;

    const section = await getSectionById(id);

    if (!section) {
      return res.status(404).json({ message: "Section not found" });
    }

    res.status(200).json(section);
  } catch (error) {
    console.error("Get Section Error:", error);
    res.status(500).json({ message: "Internal server error" });
  }
};

/* ===================== UPDATE SECTION ===================== */
export const updateSectionController = async (req, res) => {
  try {
    const { id } = req.params;

    const {
      section_name,
      course_id,
      semester,
      strength,
      batch_year,
      status
    } = req.body;

    if (
      !section_name ||
      !course_id ||
      !semester ||
      !strength ||
      !batch_year ||
      !status
    ) {
      return res.status(400).json({ message: "All fields are required" });
    }

    // check course
    if (!(await courseExistsById(course_id))) {
      return res.status(404).json({ message: "Course not found" });
    }

    const affectedRows = await updateSection(id, {
      section_name,
      course_id,
      semester,
      strength,
      batch_year,
      status
    });

    if (!affectedRows) {
      return res.status(404).json({ message: "Section not found" });
    }

    res.status(200).json({ message: "Section updated successfully" });
  } catch (error) {
    console.error("Update Section Error:", error);
    res.status(500).json({ message: "Internal server error" });
  }
};

/* ===================== DELETE SECTION (SOFT) ===================== */
export const deleteSectionController = async (req, res) => {
  try {
    const { id } = req.params;

    const affectedRows = await softDeleteSection(id);

    if (!affectedRows) {
      return res.status(404).json({ message: "Section not found" });
    }

    res.status(200).json({ message: "Section deleted successfully" });
  } catch (error) {
    console.error("Delete Section Error:", error);
    res.status(500).json({ message: "Internal server error" });
  }
};
