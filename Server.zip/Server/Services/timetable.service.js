import { pool } from "../config/dbConn.js";

/* ===========================
   HELPER FUNCTIONS
=========================== */

/* get all active, non-break slots */
const getAvailableSlots = async () => {
  const [rows] = await pool.query(
    `SELECT slot_id, day, slot_order
     FROM time_slots
     WHERE is_break = 0
       AND status = 'ACTIVE'
       AND deleted_at IS NULL
     ORDER BY day, slot_order`
  );
  return rows;
};

/* get sections */
const getSections = async () => {
  const [rows] = await pool.query(
    `SELECT * FROM sections WHERE is_deleted = 0`
  );
  return rows;
};

/* get subjects for a section/course */
const getSubjectsBySection = async (course_id) => {
  const [rows] = await pool.query(
    `SELECT * FROM subjects WHERE course_id = ? AND is_deleted = 0`,
    [course_id]
  );
  return rows;
};

/* get teachers who can teach a subject */
const getTeachersForSubject = async (subject_id) => {
  const [rows] = await pool.query(
    `SELECT t.*
     FROM teacher_subject ts
     JOIN teachers t ON t.teacher_id = ts.teacher_id
     WHERE ts.subject_id = ?
       AND ts.is_deleted = 0
       AND t.is_deleted = 0`,
    [subject_id]
  );
  return rows;
};

/* get suitable rooms */
const getRoomsForSubject = async (subject, sectionStrength) => {
  const [rows] = await pool.query(
    `SELECT *
     FROM rooms
     WHERE room_type = ?
       AND capacity >= ?
       AND is_deleted = 0`,
    [subject.is_lab ? "LAB" : "CLASSROOM", sectionStrength]
  );
  return rows;
};

/* shuffle array for randomness */
const shuffleArray = (array) => array.sort(() => Math.random() - 0.5);

/* Map weekdays to actual dates in a week */
const getWeekdayDates = (startOfWeek) => {
  const daysMap = { MON: 1, TUE: 2, WED: 3, THU: 4, FRI: 5, SAT: 6 };
  const result = {};
  for (const [dayName, dayNumber] of Object.entries(daysMap)) {
    const date = new Date(startOfWeek);
    date.setDate(startOfWeek.getDate() + (dayNumber - startOfWeek.getDay() + 7) % 7);
    result[dayName] = date.toISOString().split("T")[0]; // YYYY-MM-DD
  }
  return result;
};

/* ===========================
   MAIN GENERATOR
=========================== */
export const generateTimetable = async (startOfWeek = new Date()) => {
  const connection = await pool.getConnection();

  try {
    await connection.beginTransaction();

    const sections = await getSections();
    const slots = await getAvailableSlots();

    // organize slots by day
    const slotsByDay = {};
    const slotDayMap = {};
    for (const slot of slots) {
      slotsByDay[slot.day] = slotsByDay[slot.day] || [];
      slotsByDay[slot.day].push(slot);
      slotDayMap[slot.slot_id] = slot.day;
    }

    // map weekdays to actual dates
    const weekDates = getWeekdayDates(startOfWeek);

    // in-memory occupancy trackers
    const occupiedTeachers = {};
    const occupiedRooms = {};
    const occupiedSections = {};

    const timetableInserts = [];
    const unassignedLogs = [];

    for (const section of sections) {
      const subjects = await getSubjectsBySection(section.course_id);

      for (const subject of subjects) {
        let remainingHours = subject.weekly_hours;

        const teachers = shuffleArray(await getTeachersForSubject(subject.subject_id));
        const rooms = shuffleArray(await getRoomsForSubject(subject, section.strength));

        if (!teachers.length || !rooms.length) {
          unassignedLogs.push(`No teachers or rooms for ${subject.name} (Section ${section.name})`);
          continue;
        }

        // assign across days evenly
        const days = Object.keys(slotsByDay);
        let dayIndex = 0;

        while (remainingHours > 0) {
          const day = days[dayIndex % days.length];
          const daySlots = shuffleArray(slotsByDay[day]);

          let assigned = false;

          for (const slot of daySlots) {
            const key = `${day}_${slot.slot_order}`;

            // check in-memory occupancy
            const occupiedT = occupiedTeachers[key] || [];
            const occupiedR = occupiedRooms[key] || [];
            const occupiedS = occupiedSections[key] || [];

            for (const teacher of teachers) {
              if (occupiedT.includes(teacher.teacher_id)) continue;

              for (const room of rooms) {
                if (occupiedR.includes(room.room_id)) continue;
                if (occupiedS.includes(section.section_id)) continue;

                // assign timetable with class_date
                timetableInserts.push([
                  section.section_id,
                  subject.subject_id,
                  teacher.teacher_id,
                  room.room_id,
                  slot.slot_id,
                  weekDates[day] // class_date
                ]);

                // mark as occupied
                occupiedTeachers[key] = [...occupiedT, teacher.teacher_id];
                occupiedRooms[key] = [...occupiedR, room.room_id];
                occupiedSections[key] = [...occupiedS, section.section_id];

                remainingHours--;
                assigned = true;
                break;
              }
              if (assigned) break;
            }
            if (assigned) break;
          }

          if (!assigned) {
            unassignedLogs.push(`Could not assign ${subject.name} for section ${section.name}, remainingHours: ${remainingHours}`);
            break;
          }

          dayIndex++;
        }
      }
    }

    // batch insert all assignments
    if (timetableInserts.length > 0) {
      await connection.query(
        `INSERT INTO timetables (section_id, subject_id, teacher_id, room_id, slot_id, class_date)
         VALUES ?`,
        [timetableInserts]
      );
    }

    await connection.commit();

    return {
      message: "Timetable generated successfully with class dates!",
      unassigned: unassignedLogs
    };
  } catch (error) {
    await connection.rollback();
    throw error;
  } finally {
    connection.release();
  }
};
