import { useEffect, useState } from "react";
import axiosInstance from "../Helper/axiosInstance";
import { toast } from "react-toastify";

const DAYS_ORDER = ["MON", "TUE", "WED", "THU", "FRI", "SAT"];

function Timetable() {
  const [sections, setSections]         = useState([]);
  const [selectedSection, setSelectedSection] = useState("");
  const [timetableData, setTimetableData]     = useState([]);
  const [generating, setGenerating]     = useState(false);
  const [loadingTT, setLoadingTT]       = useState(false);
  const [generated, setGenerated]       = useState(false);

  // ── Fetch sections ──
  useEffect(() => {
    axiosInstance.get("/sections")
      .then((res) => setSections(res.data.data || []))
      .catch(() => toast.error("Failed to load sections"));
  }, []);

  // ── Fetch timetable when section changes ──
  useEffect(() => {
    if (!selectedSection) { setTimetableData([]); return; }
    const fetch = async () => {
      setLoadingTT(true);
      try {
        const res = await axiosInstance.get(`/timetable/section/${selectedSection}`);
        setTimetableData(res.data.data || []);
      } catch (err) {
        if (err.response?.status === 404) {
          setTimetableData([]);
        } else {
          toast.error("Failed to load timetable");
        }
      } finally {
        setLoadingTT(false);
      }
    };
    fetch();
  }, [selectedSection, generated]);

  // ── Generate timetable ──
  const handleGenerate = async () => {
    if (!window.confirm("This will regenerate the entire timetable. Continue?")) return;
    setGenerating(true);
    try {
      const res = await axiosInstance.post("/timetable/generate");
      toast.success(res.data.message || "Timetable generated!");
      setGenerated((p) => !p); // trigger refetch
    } catch (err) {
      toast.error(err.response?.data?.message || "Generation failed");
    } finally {
      setGenerating(false);
    }
  };

  // ── Group timetable by day ──
  const byDay = DAYS_ORDER.reduce((acc, day) => {
    acc[day] = timetableData.filter((r) => r.day === day);
    return acc;
  }, {});

  const activeDays = DAYS_ORDER.filter((d) => byDay[d].length > 0);

  const selectedSectionName = sections.find(
    (s) => String(s.section_id) === String(selectedSection)
  )?.section_name || "";

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 p-6">
      <div className="max-w-6xl mx-auto space-y-8">

        {/* Header */}
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div>
            <h1 className="text-2xl font-bold text-slate-100">Timetable</h1>
            <p className="text-slate-400 text-sm mt-1">Generate and view section timetables</p>
          </div>

          <button
            onClick={handleGenerate}
            disabled={generating}
            className="flex items-center gap-2 px-5 py-2.5 rounded-lg bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-semibold text-sm transition-colors disabled:opacity-50 shrink-0"
          >
            {generating ? (
              <>
                <svg className="w-4 h-4 animate-spin" fill="none" viewBox="0 0 24 24">
                  <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"/>
                  <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8v8z"/>
                </svg>
                Generating...
              </>
            ) : (
              <>⚡ Generate Timetable</>
            )}
          </button>
        </div>

        {/* Section Selector */}
        <div className="bg-slate-900 border border-slate-800 rounded-xl p-5">
          <label className="text-xs font-semibold uppercase tracking-widest text-slate-400 block mb-3">
            View Timetable for Section
          </label>
          <select
            value={selectedSection}
            onChange={(e) => setSelectedSection(e.target.value)}
            className="w-full sm:w-80 px-3 py-2 rounded-lg bg-slate-800 border border-slate-700 text-sm text-slate-100 focus:outline-none focus:border-emerald-500"
          >
            <option value="">Select a section...</option>
            {sections.map((s) => (
              <option key={s.section_id} value={s.section_id}>
                {s.section_name} — Semester {s.semester} ({s.batch_year})
              </option>
            ))}
          </select>
        </div>

        {/* Timetable Grid */}
        {selectedSection && (
          loadingTT ? (
            <div className="py-16 text-center text-slate-500 text-sm">Loading timetable...</div>
          ) : timetableData.length === 0 ? (
            <div className="bg-slate-900 border border-slate-800 rounded-xl py-16 text-center">
              <p className="text-slate-400 text-sm">No timetable found for this section.</p>
              <p className="text-slate-600 text-xs mt-1">Click "Generate Timetable" to create one.</p>
            </div>
          ) : (
            <div className="space-y-4">
              <h2 className="text-sm font-semibold text-slate-300">
                Schedule for <span className="text-emerald-400">{selectedSectionName}</span>
              </h2>

              {activeDays.map((day) => (
                <div key={day} className="bg-slate-900 border border-slate-800 rounded-xl overflow-hidden">
                  {/* Day header */}
                  <div className="px-5 py-3 bg-slate-800/60 border-b border-slate-800 flex items-center gap-3">
                    <span className="text-xs font-bold uppercase tracking-widest text-emerald-400 w-10">{day}</span>
                    <span className="text-xs text-slate-500">{byDay[day].length} slot{byDay[day].length !== 1 ? 's' : ''}</span>
                  </div>

                  {/* Slots */}
                  <div className="divide-y divide-slate-800">
                    {byDay[day]
                      .sort((a, b) => a.start_time.localeCompare(b.start_time))
                      .map((row) => (
                        <div
                          key={row.timetable_id}
                          className="px-5 py-4 flex flex-col sm:flex-row sm:items-center gap-3 hover:bg-slate-800/30 transition-colors"
                        >
                          {/* Time */}
                          <div className="shrink-0 w-36">
                            <span className="text-xs font-mono text-slate-300">
                              {row.start_time} – {row.end_time}
                            </span>
                          </div>

                          {/* Subject */}
                          <div className="flex-1">
                            <p className="text-sm font-medium text-slate-100">{row.subject_name}</p>
                          </div>

                          {/* Teacher */}
                          <div className="flex items-center gap-2 text-xs text-slate-400">
                            <span>👨‍🏫</span>
                            <span>{row.teacher_name}</span>
                          </div>

                          {/* Room */}
                          <div className="flex items-center gap-2 text-xs text-slate-400">
                            <span>🚪</span>
                            <span>{row.room_no ?? row.room_code}</span>
                          </div>
                        </div>
                      ))}
                  </div>
                </div>
              ))}
            </div>
          )
        )}

      </div>
    </div>
  );
}

export default Timetable;