import { createAsyncThunk, createSlice } from "@reduxjs/toolkit";
import axiosInstance from "../Helper/axiosInstance";
import { toast } from "react-toastify";

/**
 * Factory function to create a reusable CRUD slice.
 *
 * @param {string} name      - Slice name and Redux key (e.g. "teacher")
 * @param {string} endpoint  - API endpoint without leading slash (e.g. "teachers")
 * @param {string} idKey     - The unique ID field on each record (default: "_id")
 */
export const createCrudSlice = (name, endpoint, idKey = "_id") => {

  // 🔵 GET ALL
  const getAll = createAsyncThunk(
    `${name}/getAll`,
    async (_, { rejectWithValue }) => {
      try {
        const res = axiosInstance.get(`/${endpoint}`);
        toast.promise(res, {
          loading: `Loading ${name}s...`,
          success: `${name}s loaded`,
          error: `Failed to load ${name}s`,
        });
        const response = await res;
        // ✅ Handle both { data: [...] } and plain array responses
        return response.data?.data ?? response.data;
      } catch (error) {
        return rejectWithValue(error.response?.data?.message);
      }
    }
  );

  // 🟢 CREATE
  const createItem = createAsyncThunk(
    `${name}/create`,
    async (data, { rejectWithValue }) => {
      try {
        const res = axiosInstance.post(`/${endpoint}`, data);
        toast.promise(res, {
          loading: `Creating ${name}...`,
          success: `${name} created successfully`,
          error: `Failed to create ${name}`,
        });
        const response = await res;

        // ✅ Backend returns different shapes:
        // Shape A: { success, data: { ...item } }         → response.data.data
        // Shape B: { success, message, teacher_id: 5 }    → need to refetch, return null
        // Shape C: { success, data: [...] }               → response.data.data
        return response.data?.data ?? null;
      } catch (error) {
        console.error(`[${name} createItem] API Error:`, error.response?.data);
        return rejectWithValue(error.response?.data?.message ?? "Create failed");
      }
    }
  );

  // 🟡 UPDATE
  const updateItem = createAsyncThunk(
    `${name}/update`,
    async ({ id, data }, { rejectWithValue }) => {
      try {
        const res = await axiosInstance.put(`/${endpoint}/${id}`, data);
        toast.success(`${name} updated successfully`);
        return res.data?.data ?? null;
      } catch (error) {
        console.error(`[${name} updateItem] API Error:`, error.response?.data);
        return rejectWithValue(error.response?.data?.message ?? "Update failed");
      }
    }
  );

  // 🔴 DELETE
  const deleteItem = createAsyncThunk(
    `${name}/delete`,
    async (id, { rejectWithValue }) => {
      try {
        await axiosInstance.delete(`/${endpoint}/${id}`);
        toast.success(`${name} deleted successfully`);
        return id;
      } catch (error) {
        console.error(`[${name} deleteItem] API Error:`, error.response?.data);
        return rejectWithValue(error.response?.data?.message ?? "Delete failed");
      }
    }
  );

  const slice = createSlice({
    name,
    initialState: {
      data: [],
      loading: false,
      error: null,
    },
    reducers: {},
    extraReducers: (builder) => {
      builder

        // GET ALL
        .addCase(getAll.pending, (state) => {
          state.loading = true;
          state.error = null;
        })
        .addCase(getAll.fulfilled, (state, action) => {
          state.loading = false;
          state.data = action.payload ?? [];
        })
        .addCase(getAll.rejected, (state, action) => {
          state.loading = false;
          state.error = action.payload;
        })

        // CREATE
        // ✅ If payload is null (backend didn't return full item), we just refetch via getAllAction in the page
        .addCase(createItem.pending, (state) => {
          state.error = null;
        })
        .addCase(createItem.fulfilled, (state, action) => {
          if (action.payload) {
            state.data.push(action.payload);
          }
          // If null, CrudForm will dispatch getAllAction() after create anyway
        })
        .addCase(createItem.rejected, (state, action) => {
          state.error = action.payload;
        })

        // UPDATE
        // ✅ If backend returns null (just { success, message }), remove stale item and let refetch handle it
        .addCase(updateItem.fulfilled, (state, action) => {
          if (!action.payload) return; // refetch will handle it
          const index = state.data.findIndex(
            (item) => item[idKey] === action.payload[idKey]
          );
          if (index !== -1) {
            state.data[index] = action.payload;
          }
        })
        .addCase(updateItem.rejected, (state, action) => {
          state.error = action.payload;
        })

        // DELETE
        .addCase(deleteItem.fulfilled, (state, action) => {
          state.data = state.data.filter(
            (item) => item[idKey] !== action.payload
          );
        })
        .addCase(deleteItem.rejected, (state, action) => {
          state.error = action.payload;
        });
    },
  });

  return {
    reducer: slice.reducer,
    actions: { getAll, createItem, updateItem, deleteItem },
  };
};